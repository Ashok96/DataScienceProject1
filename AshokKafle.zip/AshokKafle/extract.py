import csv
#from _future_ import print_function
from collections import Counter
from functools import reduce
import math
from matplotlib import pyplot as plt

with open('LANGEVINDATA.txt', 'r') as csv_file:
  csv_reader = csv.reader(csv_file, delimiter =' ')
  FieldofInterest = [ "Time", "Occupant_Number","Occupancy_1","Indoor_Ambient_Temp", "Indoor_Relative_Humidity", "Indoor_Air_Velocity", "Indoor_Mean_Radiant_Temp", "Predicted_Mean_Vote"]
  Indexes = [0,1,2,5,6,7,8,117]
  final_list =[] #The final list to contain all the dictionaries

  for line in csv_reader:
    dict_col = {}
    for i in range(0, len(Indexes)):
      dict_col[FieldofInterest[i]]=line[Indexes[i]]
    final_list.append(dict_col)
  #print(final_list)

#Now write the dictionaries from the final_list into a new file 
with open('processed_data.csv', 'w') as new_file:
    fieldnames = [ "Time", "Occupant_Number", "Occupancy_1","Indoor_Ambient_Temp", "Indoor_Relative_Humidity", "Indoor_Air_Velocity", "Indoor_Mean_Radiant_Temp", "Predicted_Mean_Vote"]
    csv_writer = csv.DictWriter(new_file,fieldnames=fieldnames, delimiter='\t')
    csv_writer.writeheader()
    for each_dict in final_list:
      csv_writer.writerow(each_dict)

'''Create a seperate list for every columns so we can pass it in functions and calculate respective means, modes and deviations'''
#def get_each_col():
time_list = [float(final_list[i]['Time']) for i in range(len(final_list)) if math.isnan(float(final_list[i]['Time']))==False]

OC = [float(final_list[i]['Occupant_Number']) for i in range(len(final_list)) if math.isnan(float(final_list[i]['Occupant_Number']))==False]

OC_1 =[float(final_list[i]['Occupancy_1']) for i in range(len(final_list)) if math.isnan(float(final_list[i]['Occupancy_1']))==False]

IAT =[float(final_list[i]['Indoor_Ambient_Temp'] )for i in range(len(final_list))if math.isnan(float(final_list[i]['Indoor_Ambient_Temp']))==False]

IRH = [float(final_list[i]['Indoor_Relative_Humidity'] )for i in range(len(final_list))if math.isnan(float(final_list[i]['Indoor_Relative_Humidity']))==False]

IAV =[float(final_list[i]['Indoor_Air_Velocity']) for i in range(len(final_list))if math.isnan(float(final_list[i]['Indoor_Air_Velocity']))==False]

IMRT = [float(final_list[i]['Indoor_Mean_Radiant_Temp']) for i in range(len(final_list)) if math.isnan(float(final_list[i]['Indoor_Mean_Radiant_Temp']))==False]


PMV = [float(final_list[i]['Predicted_Mean_Vote']) for i in range(len(final_list))if math.isnan(float(final_list[i]['Predicted_Mean_Vote']))==False]

# Calculate mean, median, mode and std deviation of each columns

def mean(col_list): #the col_list created above would be passed here
  count = 0
  total =0
  for i in range(len(col_list)):
    # if col_list[i] == 'NaN' or col_list[i] == 'nan':
    #   continue
    total +=col_list[i]
    count +=1
  return total/count

print(mean()
print("The mean of time_list is ", mean(time_list))
print("The mean of Occupancy_number is ",mean(OC))
print("The mean of IAT is ", mean(IAT))
print("The mean of IRH is ", mean(IRH))
print("The mean of IAV is ", mean(IAV))
print("The mean of IMRT is ",mean(IMRT))
print("The mean of PMV is ",mean(PMV) )

def median(col_list):
  '''find the mid value of the col_list'''
  length = len(col_list)
  sorted_col_list = sorted(col_list)
  mid = length //2
  if (length % 2 == 1): # if odd return the mid Value
    return sorted_col_list[mid]
  else: # if the length is even, return the average of two middles
    lo = mid - 1
    hi = mid
    return(sorted_col_list[lo] + sorted_col_list[hi])/2
print("The median of time_list is ",median(time_list))
print("The median of Occupancy_number is ",median(OC))
print("The median of IAT is ", median(IAT))
print("The median of IRH is ", median(IRH))
print("The median of IAV is ", median(IAV))
print("The median of IMRT is ",median(IMRT))
print("The median of PMV is ",median(PMV) )

'''calculate mode of each column '''
def mode(col_list):
  data =Counter(col_list)
  
  mode_list =[] #can be more than one, so better to put in list
  for i, j in data.items():
    if j == max((data.values())):
      mode_list.append(i)
  return mode_list
print("The mode of time_list is ",mode(time_list))
print("The mode of Occupancy_number is ",mode(OC))
print("The mode of IAT is ", mode(IAT))
print("The mode of IRH is ", mode(IRH))
print("The mode of IAV is ", mode(IAV))
print("The mode of IMRT is ",mode(IMRT))
print("The mode of PMV is ",mode(PMV))


def deviation(col_list): 
  '''deviation = data item - mean'''
  x_bar = mean(col_list)
  return [(x_i- x_bar ) for x_i in col_list]
#print('The deviation of OC is ,', deviation(OC))

def variance(col_list):
  '''calculate the variance'''
  dev_list = deviation(col_list)
  dev_list_squared = [(dev_list[i] **2) for i in range(len(dev_list))]
  sum_of_squares = reduce((lambda x, y: x+ y), dev_list_squared)
  return sum_of_squares/ (len(col_list)-1)

'''Now calculate std_deviation using variance function'''
def  standard_deviation(col_list):
  return math.sqrt(variance(col_list))
print('The standard deviation of time_list is ', standard_deviation(time_list))
print('The standard deviation of Occupancy_number is ', standard_deviation(OC))
print('The standard deviation of IAT is ', standard_deviation(IAT))
print('The standard deviation of IRH is ', standard_deviation(IRH))
print('The standard deviation of IAV is ', standard_deviation(IAV))
print('The standard deviation of IMRT is ', standard_deviation(IRH))
print('The standard deviation of PMV is ', standard_deviation(PMV))


def time_Hist(col_list):
    tbins = [x for x in range(735080,735450,20)]
    plt.hist(col_list, tbins, histtype='bar',rwidth=0.95)
    plt.xlabel('Time')
    plt.ylabel('Frequency distribution')
    plt.title('Time Histogram')
    plt.savefig('time_list1.png')
time_Hist(time_list)


def IAT_Hist(col_list):
  bins = [x for x in range(20,25)]
  plt.hist(col_list, bins, histtype='bar',rwidth=0.35)
  plt.xlabel('Indoor_Ambient_Temperature')
  plt.ylabel('Frequency distribution')
  plt.savefig('IAT.png')
IAT_Hist(IAT)

'''for Occupancy_number histogram'''
def OC_Hist(col_list):
    bins = [x for x in range(20)]
    plt.hist(col_list, bins, histtype='bar',rwidth=0.95)
    plt.xlabel('Occupancy_number')
    plt.ylabel('Frequency distribution')
    plt.title('Occupancy_number Histogram')
    plt.savefig('OC.png')
OC_Hist(OC)

def IRH_Hist(col_list):
    bins = [x for x in range(15,80)]
    plt.hist(col_list, bins, histtype='bar',rwidth=0.95)
    plt.xlabel('Indoor_Relative_Humidity')
    plt.ylabel('Frequency distribution')
    plt.title('Indoor Relative Humidity Histogram')
    plt.savefig('IRH.png')
IRH_Hist(IRH)

def IAV_Hist(col_list):
    i =0
    bins =[]
    while i< 0.33:
      bins.append(i)
      i+=0.01
    plt.hist(col_list, bins, histtype='bar',rwidth=0.8)
    plt.xlabel('Indoor_Air_Velocity')
    plt.ylabel('Frequency distribution')
    plt.title('Indoor Air Velocity Histogram')
    plt.savefig('IAV.png')
IAV_Hist(IAV)

def IMRT_Hist(col_list):
  bins = [x for x in range(15,35)]
  plt.hist(col_list, bins, histtype='bar',rwidth=0.75)
  plt.xlabel('Indoor_Mean_Radian_Temperature')
  plt.ylabel('Frequency distribution')
  plt.savefig('IMRT1.png')
IMRT_Hist(IMRT)

def PMV_Hist(col_list):
    i = -3.0
    bins =[]
    while i< max(PMV):
      bins.append(i)
      i+=0.1
    plt.hist(col_list, bins, histtype='bar',rwidth=0.85)
    plt.xlabel('Predicted Mean Vote')
    plt.ylabel('Frequency distribution')
    plt.title('Predicted Mean Vote Histogram')
    plt.savefig('PMV.png')
PMV_Hist(PMV)




'''part 2 a) Getting scatter plot of INDOOR Ambient Temp and INDOOR Mean Radiant Temp'''

def scatter_plot_1(col_list1, col_list2):
  plt.scatter(col_list1,col_list2)
  plt.title('INDOOR Ambient Tem Vs INDOOR Mean Radiant Temp')
  plt.xlabel('IAT data',color ='r')
  plt.ylabel('IMRT data',color='b')
  plt.savefig('IATvsIMRTs.png')
scatter_plot_1(IAT,IMRT)

'''Calculate pearson's correlation coefficient'''
def covariance(col_list1,col_list2):  #Sum of product of corresponding X's and Y's distance to the mean divided by count - 1
  for i in range(0, len(col_list1)):
    sum =0
    dist_frm_mean1 = col_list1[i] - mean(col_list1)
    dist_frm_mean2 = col_list2[i]- mean(col_list2)
    multiplied = dist_frm_mean1 * dist_frm_mean2
    sum += multiplied
  return sum/(len(col_list1)-1)

def correlation( col_list1,col_list2):
  std_1 = standard_deviation(col_list1)
  std_2 = standard_deviation(col_list2)
  calc_covariance= covariance(col_list1, col_list2)
  coeff_correlation = calc_covariance /(std_1 * std_2)
  return coeff_correlation
print('Finally')
print( 'The pierson correlation coefficient is',correlation(IAT,IMRT)) 

print('The length of iAt is', len(IAT))
print('The length of IRH is', len(time_list))



'''part 2ca, Scatter plot of INDOOR Ambient Temp and INDOOR Relative Humidity and calculate correlation coefficient'''
def scatter_plot_2(col_list1, col_list2):
  plt.scatter(col_list1,col_list2)
  plt.title('INDOOR AMbient Temp Vs INDOOR Relative Humidity')
  plt.xlabel('IAT data')
  plt.ylabel('IRH data')
  plt.savefig('IATvsIRH.png')
  print('The correlation coefficient of IAT and IRH is' ,correlation(IAT, IRH))
scatter_plot_2(IAT, IRH[0:len(IAT)])

IAT_fahrenheit = [(x*1.8)+32 for x in IAT]
def plotFahrenheit():
  plt.scatter(IAT_fahrenheit,IRH[0:len(IAT_fahrenheit)])
  plt.title('INDOOR Ambient Temp(Fahrenheit) Vs Indoor_Relative_Humidity(Celsius)')
  plt.xlabel('IAT fahrenheit')
  plt.ylabel('IRH celsius')
  plt.savefig('IAT(f) Vs IRH(celsius)')
  print('The correlation between IAT in fahrenheit adnd IRH in celsius is',correlation(IAT_fahrenheit,IRH))
plotFahrenheit()


#part2cc (std deviation 1 and mean 0)

def scatterPlotMeanDevScale():
  temp_mean = mean(IAT)
  temp_sd = standard_deviation(IRH)
  humidity_mean = mean(IRH)
  humidity_sd = standard_deviation(IRH)
  new_IAT = [i - ((float(temp_mean)/float(temp_sd))) for i in IAT]
  new_IRH = [j - ((float(humidity_mean)/float(humidity_sd)))for j in IRH ]
  plt.scatter(new_IAT, new_IRH[0:len(new_IAT)]);
  plt.title('IAT Vs IRH with mean0 and std 1')
  plt.xlabel('IAT')
  plt.ylabel('IRH')
  plt.savefig('Meanandstd_IAT_IRH')
  print(correlation(new_IAT,new_IRH))
scatterPlotMeanDevScale()

#part 2d repeat 2.a and c with occupant 1
with open('occupant_1.csv', 'w') as f:
  #for each_dict in final_list:
  #if each_dict['Occupant_Number']=="1.000000":
  OC1_time_list = [float(final_list[i]['Time']) for i in range(len(final_list)) if final_list[i]['Occupant_Number']=='1.000000' and math.isnan(float(final_list[i]['Time']))==False]
  
  
  OC1_OC = [float(final_list[i]['Occupant_Number']) for i in range(len(final_list)) if final_list[i]['Occupant_Number']=='1.000000'and math.isnan(float(final_list[i]['Occupant_Number']))==False]
      
  OC1_IAT =[float(final_list[i]['Indoor_Ambient_Temp'] )for i in range(len(final_list))if  final_list[i]['Occupant_Number']=='1.000000'and math.isnan(float(final_list[i]['Indoor_Ambient_Temp']))==False]

  OC1_IRH = [float(final_list[i]['Indoor_Relative_Humidity'] )for i in range(len(final_list))if final_list[i]['Occupant_Number']=='1.000000' and math.isnan(float(final_list[i]['Indoor_Relative_Humidity']))==False]

  OC1_IAV =[float(final_list[i]['Indoor_Air_Velocity']) for i in range(len(final_list))if  final_list[i]['Occupant_Number']=='1.000000'and math.isnan(float(final_list[i]['Indoor_Air_Velocity']))==False]

  OC1_IMRT = [float(final_list[i]['Indoor_Mean_Radiant_Temp']) for i in range(len(final_list)) if  final_list[i]['Occupant_Number']=='1.000000' and math.isnan(float(final_list[i]['Indoor_Mean_Radiant_Temp']))==False]


  OC1_PMV = [float(final_list[i]['Predicted_Mean_Vote']) for i in range(len(final_list))if  final_list[i]['Occupant_Number']=='1.000000' and math.isnan(float(final_list[i]['Predicted_Mean_Vote']))==False]
  OC1_final_list = [OC1_time_list,OC1_OC,OC1_IAT,OC1_IRH, OC1_IAV, OC1_IMRT,OC1_PMV]
  


  fieldnames = [ "OC1_Time", "OC1_Occupant_Number", "OC1_Occupancy_1","OC1_Indoor_Ambient_Temp", "OC1_Indoor_Relative_Humidity", "OC1_Indoor_Air_Velocity", "OC1_Indoor_Mean_Radiant_Temp", "OC1_Predicted_Mean_Vote"]
  csv_writer = csv.writer(f)
  csv_writer.writerow(fieldnames)
  for i in OC1_final_list:
    csv_writer.writerow(i)


print("The mean of OC1 time_list is ", mean(OC1_time_list))
print("The mean of OC1 Occupancy_number is ",mean(OC1_OC))
print("The mean of OC1 IAT is ", mean(OC1_IAT))
print("The mean of OC1 IRH is ", mean(OC1_IRH))
print("The mean of OC1 IAV is ", mean(OC1_IAV))
print("The mean of OC1 IMRT is ",mean(IMRT))
print("The mean of OC1 PMV is ",mean(PMV) )

'''Part 2e time ending with 0.5000 '''
#part 2e repeat 2.a and c with times ending in .50000
with open('tod_1200.csv', 'w') as f1:
  #for each_dict in final_list:
  #if each_dict['Time'].split('.')[1] =="500000":
  t5_time_list = [float(final_list[i]['Time']) for i in range(len(final_list)) if final_list[i]['Time'].split('.')[1]=='500000' and math.isnan(float(final_list[i]['Time']))==False]
  
  t5_OC = [float(final_list[i]['Occupant_Number']) for i in range(len(final_list)) if final_list[i]['Time'].split('.')[1]=='500000' and math.isnan(float(final_list[i]['Occupant_Number']))==False]
      
  t5_IAT =[float(final_list[i]['Indoor_Ambient_Temp'] )for i in range(len(final_list))if final_list[i]['Time'].split('.')[1]=='500000' and math.isnan(float(final_list[i]['Indoor_Ambient_Temp']))==False]

  t5_IRH = [float(final_list[i]['Indoor_Relative_Humidity'] )for i in range(len(final_list))if final_list[i]['Time'].split('.')[1]=='500000' and math.isnan(float(final_list[i]['Indoor_Relative_Humidity']))==False]

  t5_IAV =[float(final_list[i]['Indoor_Air_Velocity']) for i in range(len(final_list))if final_list[i]['Time'].split('.')[1]=='500000'and math.isnan(float(final_list[i]['Indoor_Air_Velocity']))==False]

  t5_IMRT = [float(final_list[i]['Indoor_Mean_Radiant_Temp']) for i in range(len(final_list)) if final_list[i]['Time'].split('.')[1]=='500000' and math.isnan(float(final_list[i]['Indoor_Mean_Radiant_Temp']))==False]


  t5_PMV = [float(final_list[i]['Predicted_Mean_Vote']) for i in range(len(final_list))if final_list[i]['Time'].split('.')[1]=='500000' and math.isnan(float(final_list[i]['Predicted_Mean_Vote']))==False]
  t5_final_list = [t5_time_list,t5_OC,t5_IAT,t5_IRH, t5_IAV, t5_IMRT,t5_PMV]
  
  fieldnames = [ "t5_Time", "t5_Occupant_Number", "t5_Indoor_Ambient_Temp", "t5_Indoor_Relative_Humidity", "t5_Indoor_Air_Velocity", "t5_Indoor_Mean_Radiant_Temp", "t5_Predicted_Mean_Vote"]
  csv_writer = csv.writer(f1)
  csv_writer.writerow(fieldnames)
  for i in t5_final_list:
    csv_writer.writerow(i)
  
print("The mean of t5 time_list is ", mean(t5_time_list))
print("The median of t5 Occupancy_number is ",median(t5_OC))
print("The mean of t5 IAT is ", mean(t5_IAT))
print("The mode of t5 IRH is ", mode(t5_IRH))
print("The mean of t5 IAV is ", mean(t5_IAV))
print("The mean of t5 IMRT is ",mean(t5_IMRT))
print("The standard deviation of t5 PMV is ",standard_deviation(t5_PMV) )
  

  



  
  









  




